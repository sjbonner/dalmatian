## ------------------------------------------------------------------------
## Load package
library(dalmation)

## ------------------------------------------------------------------------
## Load pied flycatcher data
data(pied_flycatchers_1)

## ------------------------------------------------------------------------
## Create variables bounding the true load
pfdata$lower=ifelse(pfdata$load==0,log(.001),log(pfdata$load-.049))
pfdata$upper=log(pfdata$load+.05)

## ------------------------------------------------------------------------
mymean=list(fixed=list(name="alpha",
       formula=~ log(IVI) + broodsize + sex,
       priors=list(c("dnorm",0,.001))))

myvar=list(fixed=list(name="psi",
      link="log",
      formula=~broodsize + sex,
      priors=list(c("dnorm",0,.001))))


## ------------------------------------------------------------------------

## Define list of arguments for jags.model()
jm.args <- list(file="pied_flycatcher_1_jags.R",n.adapt=100)

## Define list of arguments for coda.samples()
cs.args <- list(n.iter=100)

## Run the model using dalmation
pfresults <- dalmation(df=pfdata,
                          mean.model=mymean,
                          variance.model=myvar,
                          jags.model.args=jm.args,
                          coda.samples.args=cs.args,
                          rounding=TRUE,
                          lower="lower",
                          upper="upper",
                          debug=FALSE)


## ------------------------------------------------------------------------
library(coda)

## Compute Gelman-Rubin Diagnostics
gelman.diag(pfresults$coda)

## Compute effective sample size
effectiveSize(pfresults$coda)

## ------------------------------------------------------------------------
library(ggmcmc)

## Examine fixed effects of mean component
ggs.mean=ggs(pfresults$coda,mymean$fixed$name)

ggs_traceplot(ggs.mean)
ggs_density(ggs.mean)
ggs_caterpillar(ggs.mean) + geom_vline(xintercept=0)

## ------------------------------------------------------------------------
## Examine fixed effects of variance component
ggs.var=ggs(pfresults$coda,myvar$fixed$name)

ggs_traceplot(ggs.var)
ggs_density(ggs.var)
ggs_caterpillar(ggs.var) + geom_vline(xintercept=0)

## ------------------------------------------------------------------------
# Random component of mean
mymean$random=list(name="epsilon",formula=~-1 + indidx)

# Random component of variance
myvar$random=list(name="xi",formula=~-1 + indidx)

## ------------------------------------------------------------------------

## Define initial values
inits <- lapply(1:3,function(i){
                    list(alpha=pfresults$coda[[i]][100,1:4],
                         psi=pfresults$coda[[i]][100,5:7],
                         y=pfresults$jags.model.args$inits[[i]]$y,
                         tau.epsilon=1,
                         tau.xi=1)
                })

## Define list of arguments for jags.model()
jm.args <- list(file="pied_flycatcher_2_jags.R",inits=inits,n.adapt=100)

## Define list of arguments for coda.samples()
cs.args <- list(n.iter=100)

## Run the model using dalmation
pfresults2 <- dalmation(df=pfdata,
                           mean.model=mymean,
                           variance.model=myvar,
                           jags.model.args=jm.args,
                           coda.samples.args=cs.args,
                           rounding=TRUE,
                           lower="lower",
                           upper="upper",
                           debug=FALSE)


## ------------------------------------------------------------------------
## Gelman Diagnostics
gelman.diag(pfresults2$coda)

## ------------------------------------------------------------------------
## Examine fixed effects of mean component
ggs.mean=ggs(pfresults2$coda,paste0("^",mymean$fixed$name))

ggs_traceplot(ggs.mean)
ggs_density(ggs.mean)
ggs_caterpillar(ggs.mean) + geom_vline(xintercept=0)

## Examine fixed effects of variance component
ggs.var=ggs(pfresults2$coda,paste0("^",myvar$fixed$name))

ggs_traceplot(ggs.var)
ggs_density(ggs.var)
ggs_caterpillar(ggs.var) + geom_vline(xintercept=0)

## ------------------------------------------------------------------------
ggs.random=ggs(pfresults2$coda,family="sd")

ggs_traceplot(ggs.random)
ggs_density(ggs.random)
ggs_caterpillar(ggs.random)


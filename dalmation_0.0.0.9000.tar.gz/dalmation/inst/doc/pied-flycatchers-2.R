## ------------------------------------------------------------------------
## Load package
library(dalmation)

## ------------------------------------------------------------------------
## Load pied flycatcher data
data(pied_flycatchers_1)

## ------------------------------------------------------------------------
## Create variables bounding the true load
pfdata$lower <- ifelse(pfdata$load==0,log(.001),log(pfdata$load-.049))
pfdata$upper <- log(pfdata$load+.05)

## ------------------------------------------------------------------------
mymean <- list(fixed=list(name="alpha",
       formula=~ log(IVI) + broodsize + sex,
       priors=list(c("dnorm",0,.001))))

myvar <- list(fixed=list(name="psi",
      link="log",
      formula=~broodsize + sex,
      priors=list(c("dnorm",0,.001))))

## ------------------------------------------------------------------------
## Generate JAGS script
modelFile <- "pied_flycatcher_1_jags.R"
generateJAGScode(modelFile,mymean,myvar,rounding=TRUE)

## ------------------------------------------------------------------------
## Generate JAGS input data
jags.data <- generateJAGSdata(pfdata,mymean,myvar,lower="lower",upper="upper")

## ------------------------------------------------------------------------
## Generate JAGS initial values
jags.inits <- generateJAGSinits(mymean,myvar,jags.data)

## ------------------------------------------------------------------------
library(rjags)

## Initialize model
model <- jags.model(modelFile,data=jags.data,inits=jags.inits)

## List parameters to monitor
parameters <- c(mymean$fixed$name,myvar$fixed$name)

## Generate 1000 samples
samples <- coda.samples(model,parameters,1000)

## ------------------------------------------------------------------------
library(ggmcmc)

## Examine fixed effects of mean component
ggs.mean <- ggs(samples,mymean$fixed$name)

ggs_traceplot(ggs.mean)
ggs_density(ggs.mean)
ggs_caterpillar(ggs.mean) + geom_vline(xintercept=0)

## ------------------------------------------------------------------------
library(ggmcmc)

## Examine fixed effects of variance component
ggs.var <- ggs(samples,myvar$fixed$name)

ggs_traceplot(ggs.var)
ggs_density(ggs.var)
ggs_caterpillar(ggs.var) + geom_vline(xintercept=0)


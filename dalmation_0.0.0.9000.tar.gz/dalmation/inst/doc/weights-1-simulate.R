## ------------------------------------------------------------------------
library(dalmation)
data(weights_1_simulate)
head(weights.df)

## ------------------------------------------------------------------------
library(dalmation)
data(weights_1_simulate)

mymean=list(fixed=list(name="alpha",formula=~ x,
            priors=list(c("dnorm",0,.001))))
myvar=list(fixed=list(name="psi",link="log",formula=~ x,
           priors=list(c("dnorm",0,.001))))

jm.args = list(file="weights_1_jags.R",n.adapt=1000)

cs.args = list(n.iter=1000)

pfresults1 <- dalmation(df=weights.df,
                       mean.model=mymean,
                       variance.model=myvar,
                       jags.model.args=jm.args,
                       coda.samples.args=cs.args,
                       response="y",
                       debug=FALSE)

summ1 = summary(pfresults1$coda)

print(round(cbind(summ1[[1]][1:4,1:2],summ1[[2]][1:4,]),2))

## ------------------------------------------------------------------------
## Specify column containing weights
myvar$weights = "n"

## Run model
jm.args = list(file="weights_2_jags.R",n.adapt=1000)

pfresults2 = dalmation(df=weights.df,
                        mean.model=mymean,
                        variance.model=myvar,
                        jags.model.args=jm.args,
                        coda.samples.args=cs.args,
                        response="y",
                        debug=FALSE)

summ2 = summary(pfresults2$coda)

## Compare results
print(round(cbind(summ2[[1]][1:4,1:2],summ2[[2]][1:4,]),2))


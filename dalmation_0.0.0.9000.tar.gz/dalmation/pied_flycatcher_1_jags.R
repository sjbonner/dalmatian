## Created by generateJAGS:  Wed Mar  2 16:51:00 2016 

model {
	 ##### Likelihood #####
	 for(i in 1:n){
		 ## Data distribution 
		 y[i] ~ dnorm(muy[i],weights[i]/pow(sdy[i],2))

		 ## Rounding
		 round1[i] <- (lower[i] < y[i])
		 round2[i] <- (y[i] < upper[i])
		 dummy[i] ~ dbern(round1[i] * round2[i])

		 resid[i] <- (y[i] - muy[i])/sdy[i]

		 ## Mean Model
		 muy[i] <- inprod(mean.fixed[i,],alpha[]) + inprod(mean.random[i,],epsilon[])

		 ## Variance Model
		 log(sdy[i]) <- inprod(variance.fixed[i,],psi[]) + inprod(variance.random[i,],xi[])

	 }

	 ##### Priors #####
	 ## Mean Model: Fixed
	 for(k in 1:alpha.n){
		alpha[k] ~ dnorm(0,0.001)
	 }

	 ## Mean Model: Random
	 for(k in 1:epsilon.ncomponents){
		 redun.epsilon[k]~ dnorm(0,1)
		 tau.epsilon[k]~ dgamma(1.5,37.5)
		 sd.epsilon[k]<- abs(redun.epsilon[k])/sqrt(tau.epsilon[k])
		 var.epsilon[k]<- pow(sd.epsilon[k],2) 
	 }

	 for(k in 1:epsilon.neffects){
		epsilon[k] ~ dnorm(0,tau.epsilon[epsilon.levels[k]])
	 }

	 ## Variance Model: Fixed
	 for(k in 1:psi.n){
		psi[k] ~ dnorm(0,0.001)
	 }
	 ## Variance Model: Random
	 for(k in 1:xi.ncomponents){
		 redun.xi[k]~ dnorm(0,1)
		 tau.xi[k]~ dgamma(1.5,37.5)
		 sd.xi[k]<- abs(redun.xi[k])/sqrt(tau.xi[k])
		 var.xi[k]<- pow(sd.xi[k],2) 
	 }

	 for(k in 1:xi.neffects){
		xi[k] ~ dnorm(0,tau.xi[xi.levels[k]])
	 }

}

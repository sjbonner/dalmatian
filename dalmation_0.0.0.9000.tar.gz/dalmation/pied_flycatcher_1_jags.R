## Created by generateJAGS:  Sun Jun 14 12:50:10 2015 

model {
	 ##### Likelihood #####
	 for(i in 1:n){
		 ## Data distribution 
		 y[i] ~ dnorm(muy[i],1/pow(sdy[i],2))

		 ## Rounding
		 round1[i] <- (lower[i] < y[i])
		 round2[i] <- (y[i] < upper[i])
		 dummy[i] ~ dbern(round1[i] * round2[i])

		 ## Mean Model
		 muy[i] <- inprod(mean.fixed[i,],alpha[])

		 ## Variance Model
		 log(sdy[i]) <- inprod(variance.fixed[i,],psi[])
	 }

	 ##### Priors #####
	 ## Mean Model: Fixed
	 for(k in 1:alpha.n){
		alpha[k] ~ dnorm(0,0.001)
	 }

	 ## Variance Model: Fixed
	 for(k in 1:psi.n){
		psi[k] ~ dnorm(0,0.001)
	 }
}

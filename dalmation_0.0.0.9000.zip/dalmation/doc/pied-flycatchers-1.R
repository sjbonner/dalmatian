## ------------------------------------------------------------------------
## Load package
library(dalmation)

## ------------------------------------------------------------------------
## Load pied flycatcher data
data(pied_flycatchers_1)

## ------------------------------------------------------------------------
## Create variables bounding the true load
pfdata$lower=ifelse(pfdata$load==0,log(.001),log(pfdata$load-.049))
pfdata$upper=log(pfdata$load+.05)

## ------------------------------------------------------------------------
mymean=list(fixed=list(name="alpha",
       formula=~ log(IVI) + broodsize + sex,
       priors=list(c("dnorm",0,.001))))

myvar=list(fixed=list(name="psi",
      link="log",
      formula=~broodsize + sex,
      priors=list(c("dnorm",0,.001))))

## ------------------------------------------------------------------------
## Generate JAGS script
modelFile1="pied_flycatcher_1_jags.R"
generateJAGScode(modelFile1,mymean,myvar,rounding=TRUE)

## ------------------------------------------------------------------------
## Generate JAGS input data
jags.data1=generateJAGSdata(pfdata,mymean,myvar,lower="lower",upper="upper")

## ------------------------------------------------------------------------
## Generate JAGS initial values
jags.inits1=generateJAGSinits(mymean,myvar,jags.data1)

## ------------------------------------------------------------------------
library(rjags)

## Initialize model
model1=jags.model(modelFile1,data=jags.data,inits=jags.inits)

## List parameters to monitor
parameters1=c(mymean$fixed$name,myvar$fixed$name)

## Generate 1000 samples
samples1=coda.samples(model1,parameters1,1000)

## ------------------------------------------------------------------------
library(ggmcmc)

## Examine fixed effects of mean component
ggs.mean=ggs(samples1,mymean$fixed$name)

ggs_traceplot(ggs.mean)
ggs_density(ggs.mean)
ggs_caterpillar(ggs.mean) + geom_vline(xintercept=0)

## ------------------------------------------------------------------------
## Examine fixed effects of variance component
ggs.var=ggs(samples1,myvar$fixed$name)

ggs_traceplot(ggs.var)
ggs_density(ggs.var)
ggs_caterpillar(ggs.var) + geom_vline(xintercept=0)

## ------------------------------------------------------------------------
# Random component of mean
mymean$random=list(name="epsilon",formula=~indidx)

# Random component of variance
myvar$random=list(name="xi",formula=~indidx)

## ------------------------------------------------------------------------
## Generate JAGS script
modelFile="pied_flycatcher_2_jags.R"
generateJAGScode(modelFile,mymean,myvar,rounding=TRUE)

## ------------------------------------------------------------------------
## Generate JAGS input data
jags.data2=generateJAGSdata(pfdata,mymean,myvar,lower="lower",upper="upper")

## ------------------------------------------------------------------------
## Set initial values
n=nrow(samples[[1]])
jags.inits2=list(alpha=samples[[1]][n,1:4],
	   psi=samples[[1]][n,5:7],
	   y=jags.inits$y,
	   tau.epsilon=1,
	   tau.xi=1)

## ------------------------------------------------------------------------
## Initialize model
model2=jags.model(modelFile,data=jags.data2,inits=jags.inits2)

## List parameters to monitor
parameters2=c(parameters1,"sd.epsilon","sd.xi")

## Generate 1000 samples
samples2=coda.samples(model2,parameters2,1000)

## ------------------------------------------------------------------------
ggs.random=ggs(samples2,family="sd")

ggs_traceplot(ggs.random)
ggs_density(ggs.random)
ggs_caterpillar(ggs.random)

